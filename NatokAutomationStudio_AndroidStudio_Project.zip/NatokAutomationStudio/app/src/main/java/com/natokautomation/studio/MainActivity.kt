package com.natokautomation.studio

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs

private val Bg = Color(0xFF0B0B12)
private val Panel = Color(0xFF171725)
private val Accent = Color(0xFFB65CFF)
private val TextMain = Color(0xFFF5F1FA)
private val Muted = Color(0xFFAAA4B5)

data class FrameShot(val timeMs: Long, val bitmap: Bitmap)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary=Accent, background=Bg, surface=Panel)) { StudioApp() } }
    }
}

@Composable
fun StudioApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("কোনো ভিডিও নির্বাচন করা হয়নি") }
    var shots by remember { mutableStateOf<List<FrameShot>>(emptyList()) }
    var status by remember { mutableStateOf("শুরু করতে একটি নাটকের ভিডিও নির্বাচন করুন") }
    var interval by remember { mutableFloatStateOf(10f) }
    var selectedTab by remember { mutableStateOf("হোম") }
    var script by remember { mutableStateOf("") }
    var googleKey by remember { mutableStateOf("") }
    var elevenKey by remember { mutableStateOf("") }
    var showKeys by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf("") }
    val zipCreator = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { destination ->
        if (destination != null) {
            scope.launch {
                exportMessage = "ZIP তৈরি হচ্ছে…"
                val result = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(destination)?.use { output ->
                            ZipOutputStream(output).use { zip ->
                                shots.forEachIndexed { index, shot ->
                                    zip.putNextEntry(ZipEntry("frame_${(index + 1).toString().padStart(4, '0')}_${shot.timeMs}ms.jpg"))
                                    shot.bitmap.compress(Bitmap.CompressFormat.JPEG, 90, zip)
                                    zip.closeEntry()
                                }
                            }
                        } ?: error("ফাইল তৈরি করা যায়নি")
                        "${shots.size}টি ছবি ZIP-এ সংরক্ষণ হয়েছে"
                    } catch (e: Exception) {
                        "ZIP এক্সপোর্ট ব্যর্থ: ${e.localizedMessage ?: "অজানা সমস্যা"}"
                    }
                }
                exportMessage = result
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
            shots = emptyList()
            status = "ভিডিও নির্বাচন হয়েছে। এখন Capture শুরু করতে পারেন।"
        }
    }

    fun captureFrames() {
        val uri = videoUri ?: run { status = "আগে একটি ভিডিও নির্বাচন করুন"; return }
        scope.launch {
            status = "স্ক্রিনশট তৈরি হচ্ছে…"
            val result = withContext(Dispatchers.IO) {
                val retriever = MediaMetadataRetriever()
                val found = mutableListOf<FrameShot>()
                try {
                    retriever.setDataSource(context, uri)
                    val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val step = (interval.toLong() * 1000L).coerceAtLeast(1000L)
                    var t = 0L
                    while (t < duration && found.size < 500) {
                        val raw = retriever.getFrameAtTime(t * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (raw != null) {
                            // Keep gallery memory use manageable on mid-range Android phones.
                            val maxSide = 1280
                            val scale = minOf(1f, maxSide.toFloat() / maxOf(raw.width, raw.height))
                            val frame = if (scale < 1f) Bitmap.createScaledBitmap(
                                raw, (raw.width * scale).toInt().coerceAtLeast(1),
                                (raw.height * scale).toInt().coerceAtLeast(1), true
                            ) else raw
                            if (frame !== raw) raw.recycle()
                            found.add(FrameShot(t, frame))
                        }
                        t += step
                    }
                } catch (e: Exception) {
                    // The status message below reports the failure without crashing the app.
                } finally { try { retriever.release() } catch (_: Exception) {} }
                removeNearDuplicates(found)
            }
            shots = result
            status = if (result.isEmpty()) "কোনো ফ্রেম পাওয়া যায়নি। ভিডিও ফরম্যাট পরীক্ষা করুন।"
                     else "${result.size}টি ইউনিক ফ্রেম তৈরি হয়েছে"
        }
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor=Panel, contentColor=TextMain) {
                listOf("হোম","গ্যালারি","ভয়েস","সেটিংস").forEach { tab ->
                    NavigationBarItem(selected=selectedTab==tab, onClick={selectedTab=tab},
                        icon={ Icon(when(tab){"হোম"->Icons.Default.Home;"গ্যালারি"->Icons.Default.Collections;"ভয়েস"->Icons.Default.RecordVoiceOver;else->Icons.Default.Settings}, null) },
                        label={Text(tab)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Accent, selectedTextColor=Accent, indicatorColor=Accent.copy(alpha=.15f)))
                }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).background(Bg).padding(16.dp)) {
            Text("NATOK AUTOMATION", color=Accent, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            Text("Studio", color=TextMain, fontSize=28.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            when(selectedTab) {
                "হোম" -> {
                    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("ভিডিও প্রজেক্ট", color=TextMain, fontSize=18.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(videoName, color=Muted)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick={picker.launch(arrayOf("video/*"))}, modifier=Modifier.fillMaxWidth(),
                                colors=ButtonDefaults.buttonColors(containerColor=Accent)) {
                                Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("নাটকের ভিডিও নির্বাচন")
                            }
                            OutlinedButton(onClick={captureFrames}, modifier=Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text("অটো স্ক্রিনশট ক্যাপচার")
                            }
                            Text("ক্যাপচার ব্যবধান: ${interval.toInt()} সেকেন্ড", color=Muted)
                            Slider(value=interval, onValueChange={interval=it}, valueRange=5f..60f, steps=10)
                            Text(status, color=if(status.contains("হয়েছে")) Color(0xFF7DE0A3) else Muted)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("টুলস", color=TextMain, fontWeight=FontWeight.Bold, fontSize=18.sp)
                    val tools = listOf("ভিডিও ট্রিম ও জুম","কালার গ্রেডিং","ডুপ্লিকেট ছবি ফিল্টার","AI স্ক্রিপ্ট এক্সপান্ড","হুক ওভারলে","সাবটাইটেল","ব্যাকগ্রাউন্ড মিউজিক","MP4 এক্সপোর্ট")
                    tools.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            pair.forEach { name ->
                                Card(Modifier.weight(1f).padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Panel)) {
                                    Text(name, Modifier.padding(14.dp), color=TextMain, fontSize=13.sp)
                                }
                            }
                            if(pair.size==1) Spacer(Modifier.weight(1f))
                        }
                    }
                    Text("উপরের কিছু টুল পরবর্তী ডেভেলপমেন্ট ধাপে যুক্ত হবে।", color=Muted, fontSize=11.sp)
                }
                "গ্যালারি" -> {
                    Text("ইউনিক স্ক্রিনশট: ${shots.size}", color=TextMain, fontSize=18.sp, fontWeight=FontWeight.Bold)
                    if(shots.isEmpty()) Text("এখনো কোনো স্ক্রিনশট নেই। হোম থেকে ভিডিও ক্যাপচার করুন।", color=Muted)
                    if (shots.isNotEmpty()) {
                        Button(onClick={zipCreator.launch("Natok_Frames.zip")}, modifier=Modifier.fillMaxWidth(),
                            colors=ButtonDefaults.buttonColors(containerColor=Accent)) {
                            Icon(Icons.Default.Archive, null); Spacer(Modifier.width(8.dp)); Text("সব ছবি ZIP হিসেবে এক্সপোর্ট")
                        }
                    }
                    if (exportMessage.isNotBlank()) Text(exportMessage, color=Muted, fontSize=12.sp)
                    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        items(shots) { shot ->
                            Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
                                Row(Modifier.padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Image(shot.bitmap.asImageBitmap(), null, Modifier.size(104.dp,64.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Text("সময়: ${shot.timeMs/1000} সেকেন্ড", color=TextMain)
                                }
                            }
                        }
                    }
                }
                "ভয়েস" -> {
                    Text("স্ক্রিপ্ট", color=TextMain, fontWeight=FontWeight.Bold)
                    OutlinedTextField(value=script,onValueChange={script=it},modifier=Modifier.fillMaxWidth().height(180.dp),placeholder={Text("এখানে বাংলা নাটক রিভিউ স্ক্রিপ্ট লিখুন…")})
                    Spacer(Modifier.height(12.dp))
                    Text("AI ভয়েস: Google AI Studio ও ElevenLabs সংযোগ পরবর্তী ধাপে যুক্ত হবে।", color=Muted)
                }
                else -> {
                    Text("API সেটিংস", color=TextMain, fontWeight=FontWeight.Bold, fontSize=20.sp)
                    Text("নিজের API Key এখানে যোগ করার UI প্রস্তুত করা হয়েছে। নিরাপদ key storage ও API integration পরবর্তী ধাপে যুক্ত করতে হবে।", color=Muted)
                    OutlinedTextField(value=googleKey,onValueChange={googleKey=it},modifier=Modifier.fillMaxWidth(),label={Text("Google AI Studio API Key")})
                    OutlinedTextField(value=elevenKey,onValueChange={elevenKey=it},modifier=Modifier.fillMaxWidth(),label={Text("ElevenLabs API Key")})
                    Button(onClick={showKeys=!showKeys}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text(if(showKeys) "Key field hide" else "Key field visible") }
                    Text("এটি প্রাথমিক UI; এখনো API-তে key পাঠানো বা সংরক্ষণ করা হয় না।", color=Muted, fontSize=12.sp)
                }
            }
        }
    }
}

private fun removeNearDuplicates(input: List<FrameShot>): List<FrameShot> {
    val kept = mutableListOf<FrameShot>()
    val hashes = mutableListOf<Long>()
    for (frame in input) {
        val hash = averageHash(frame.bitmap)
        if (hashes.none { java.lang.Long.bitCount(it xor hash) <= 5 }) {
            kept.add(frame); hashes.add(hash)
        }
    }
    return kept
}

private fun averageHash(bitmap: Bitmap): Long {
    val small = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
    var sum = 0L
    val values = IntArray(64)
    var i = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        val c = small.getPixel(x,y)
        val gray = (android.graphics.Color.red(c)*299 + android.graphics.Color.green(c)*587 + android.graphics.Color.blue(c)*114)/1000
        values[i++] = gray; sum += gray
    }
    val avg = sum / 64
    var hash = 0L
    for (v in values) hash = (hash shl 1) or if (v >= avg) 1L else 0L
    if (small !== bitmap) small.recycle()
    return hash
}
