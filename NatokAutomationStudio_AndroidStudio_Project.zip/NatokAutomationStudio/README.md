# Natok Automation Studio — Android starter project

This is an Android Studio source project (not a prebuilt APK).

## Implemented in this starter
- Bengali dark-theme Android app shell
- Video selection through Android's document picker
- Frame extraction using `MediaMetadataRetriever`
- Configurable 5–60 second capture interval
- Basic perceptual-hash duplicate-frame filtering
- Gallery preview of extracted frames
- ZIP export of extracted frames through Android Save dialog
- Captured frames scaled to a maximum 1280px edge to reduce memory pressure
- Script input screen and API settings UI placeholders

## Not implemented yet
- Real Google AI Studio / ElevenLabs network integration
- Secure API-key storage
- Video trim, crop, zoom, color grading and final MP4 rendering
- Hook/overlay/music/subtitle composition
- Batch queue and ZIP export

These are not represented as working features in this starter. ZIP export saves the captured JPEG frames only; it does not render an edited MP4.

## Build
1. Install Android Studio (latest stable) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync and SDK installation (compile SDK 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be generated under `app/build/outputs/apk/debug/`.

Minimum Android version: Android 8.0 (API 26).

## Cloud APK build (GitHub Actions)
A workflow is included at `.github/workflows/android-apk.yml`.
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab and run **Build Natok Automation Studio APK** (or push to `main`/`master`).
3. When the workflow finishes, open its run and download the `NatokAutomationStudio-debug-apk` artifact.
4. Extract the artifact and install `app-debug.apk` on your Android phone. You may need to allow installation from that source.

This produces a debug APK, not a Play Store release-signed APK.
